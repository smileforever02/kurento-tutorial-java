# Test

The test file should be named as `*.spec.coffee`.

All test files are bundled to `specs.bundle.js` file, and it will be executed
under browser(chrome) environment.
